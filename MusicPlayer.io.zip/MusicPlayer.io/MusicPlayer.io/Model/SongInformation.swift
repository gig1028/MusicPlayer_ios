//
//  SongInformation.swift
//  MusicPlayer.io
//
//  Created by gurvir singh on 12/10/23.
//

import Foundation

struct Song: Codable {
    
    var songTitle: String
    var songArtist: String
    var songTotalTime: Int
    var songImage: Data
}

struct APIError: Codable {
    var errorMessage: String
}
