//
//  MusicListViewModel.swift
//  MusicPlayer.io
//
//  Created by gurvir singh on 12/10/23.
//

import Foundation

class MusicListViewModel {
    
    var delegate: MusicListVCDelegate?
    var songsList: [Song]?
    
    init(_ delegate: MusicListVCDelegate) {
        self.delegate = delegate
    }
    
    func getMusicSongList() {
        Networking.shared.fetchSongListFromServer { songs in
            self.songsList = songs
            self.delegate?.reloadTableView()
        } onFailure: { error in
            debugPrint(error)
        }
    }
    
}

