//
//  Networking.swift
//  MusicPlayer.io
//
//  Created by gurvir singh on 12/10/23.
//

import Foundation

//typealias success
enum Apis: String {
    case main = "https://docs.google.com"
    case songList = "/song_list"
    case songDescription = "/song_description"
}

class Networking {
    
    static let shared = Networking()
    let session = URLSession(configuration: .default)
    
    
    func fetchSongListFromServer(onSuccess: @escaping ([Song]) -> Void, onFailure: @escaping (String) -> Void) {
        
        guard let url = URL(string: Apis.main.rawValue + Apis.songList.rawValue) else {
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        let task = session.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
//                guard let error = error else {
//                    onFailure(error?.localizedDescription ?? "")
//                    return
//                }
                
//                guard let data = data, let response = response as? HTTPURLResponse else {
//                    onFailure("Invalid Data or Response")
//                    return
//                }
                onSuccess(MusicDataSource.shared.getSongs())
//                do {
//                    if response.statusCode == 200 {
//                        onSuccess(MusicDataSource.shared.getSongs())
//                        let songList = try JSONDecoder().decode([Song].self, from: data)
//                        onSuccess(songList)
//                    } else {
//                        let error = try JSONDecoder().decode(APIError.self, from: data)
//                        onFailure(error.errorMessage)
//                    }
//                } catch {
//                    onFailure(error.localizedDescription)
//                }
            }
        }
        task.resume()
    }
    
    
    
    
    
    
}
