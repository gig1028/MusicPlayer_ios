//
//  SongItemCell.swift
//  MusicPlayer.io
//
//  Created by gurvir singh on 12/10/23.
//

import UIKit

class SongItemCell: UITableViewCell {
    
    @IBOutlet weak var songImageView: UIImageView!
    @IBOutlet weak var songTitle: UILabel!
    @IBOutlet weak var songArtist: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setupUI(_ song: Song) {
        self.songArtist.text = song.songArtist
        self.songTitle.text = song.songTitle
        self.songImageView.image = UIImage(data: song.songImage)        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
