//
//  ViewController.swift
//  MusicPlayer.io
//
//  Created by gurvir singh on 12/10/23.
//

import UIKit

protocol MusicListVCDelegate {
    func reloadTableView()
}


class MusicListViewController: UIViewController, MusicListVCDelegate {
    
    @IBOutlet weak var songListTableView: UITableView!
    var musicViewModel: MusicListViewModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
        musicViewModel = MusicListViewModel(self)
        musicViewModel.getMusicSongList()
        // Do any additional setup after loading the view.
    }
    
    func configureTableView() {
        songListTableView.dataSource = self
        songListTableView.delegate = self
        songListTableView.estimatedRowHeight = 150
        songListTableView.register(UINib(nibName: "SongItemCell", bundle: nil), forCellReuseIdentifier: "SongItemCell")
    }

    func reloadTableView() {
        songListTableView.reloadData()
    }


}


extension MusicListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return musicViewModel.songsList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "SongItemCell", for: indexPath) as? SongItemCell else {
            return UITableViewCell()
        }
        if let song = musicViewModel.songsList?[indexPath.row] {
            cell.setupUI(song)
        }
        cell.selectionStyle = .none
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let vc = self.storyboard?.instantiateViewController(identifier: "SongDescriptionViewController") else {
            return
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let vc = segue.destination as? SongDescriptionViewController else {
            return
        }
        guard let song = sender as? Song else {
            return
        }
        vc.setupVC(song)
    }
    
}
