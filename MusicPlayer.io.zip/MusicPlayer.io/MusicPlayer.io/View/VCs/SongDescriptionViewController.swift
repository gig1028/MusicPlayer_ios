//
//  SongDescriptionViewController.swift
//  MusicPlayer.io
//
//  Created by gurvir singh on 12/10/23.
//

import UIKit

class SongDescriptionViewController: UIViewController {
    
    @IBOutlet weak var songImageView: UIImageView!
    @IBOutlet weak var songArtist: UILabel!

    var song: Song?

    override func viewDidLoad() {
        super.viewDidLoad()
        self.songArtist.text = song?.songArtist ?? ""
        self.songImageView.image = UIImage(data: song?.songImage ?? Data())
        self.navigationItem.title = song?.songArtist ?? ""

        // Do any additional setup after loading the view.
    }
    
    func setupVC(_ song: Song) {
        self.song = song
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
