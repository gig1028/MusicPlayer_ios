//
//  MusicDataSource.swift
//  MusicPlayer.io
//
//  Created by gurvir singh on 12/10/23.
//

import Foundation


class MusicDataSource {
    
    static let shared = MusicDataSource()
    
    var songs: [Song] = [Song(songTitle: "Hello There", songArtist: "Katy Perry", songTotalTime: 345, songImage: Data()),
                         Song(songTitle: "Fast Moving", songArtist: "Taylot Siwft", songTotalTime: 234, songImage: Data()),
                         Song(songTitle: "U got me here", songArtist: "Eminem", songTotalTime: 765, songImage: Data()),
                         Song(songTitle: "YOYOYO", songArtist: "Shawn Mendas", songTotalTime: 345, songImage: Data())
    ]
    
    func getSongs() -> [Song] {
        return songs
    }
    
    
}




